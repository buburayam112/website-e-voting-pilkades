PAKET JADWAL PILKADES E-VOTING MEMPAWAH 2026

Isi paket:
1. jadwal-12-desa-pilkades-2026.csv / .json: 12 desa sesuai 5 gelombang dan tanggal/TPS pada screenshot pengguna, dilengkapi kode wilayah.
2. master-60-desa-mempawah-dengan-status-gelombang.csv / .json: master 60 desa dengan 12 berstatus gelombang_saat_ini dan 48 belum_dijadwalkan.

Sumber kode: Lampiran Peraturan Bupati Mempawah Nomor 43 Tahun 2022 tentang Kode dan Data Wilayah Administrasi Pemerintahan Kabupaten Mempawah Tahun 2022. Perbup menetapkan kode 10 digit; kode disimpan sebagai string dan kolom kode_tampilan memakai titik sesuai format lampiran.

Sumber jadwal: screenshot yang diberikan pengguna, yang menampilkan keterangan Lampiran II SK Bupati Mempawah No. 460/94. Jadwal/tanggal/TPS pada file ini ditranskripsi dari screenshot dan belum diverifikasi terhadap naskah SK lengkap.

CATATAN KOREKSI PENTING:
- Screenshot mencantumkan Sungai Bakau Besar Laut pada Kecamatan Mempawah Timur. Namun Lampiran Perbup Mempawah 43/2022 memberikan kode 61.02.07.2004 dan menempatkannya di Kecamatan Sungai Pinyuh. Kode dan kecamatan pada file mengikuti lampiran Perbup; kolom kecamatan_pada_screenshot dan catatan_verifikasi menyimpan perbedaan ini.
- Karena koreksi tersebut, daftar kecamatan Wave III yang dihitung dari desa dan kode individual adalah Sungai Pinyuh dan Segedong, tidak termasuk Mempawah Timur. Ringkasan kecamatan Wave III di screenshot menyebut Mempawah Timur, Sungai Pinyuh, dan Segedong; perlu diperiksa apakah label desa atau ringkasan pada SK salah/ada desa yang terlewat.
- Lampiran kode Perbup 43/2022 merujuk pada data Kemendagri 2022. Kemendagri menerbitkan pemutakhiran kode pada 2025 (Kepmendagri 300.2.2-2138/2025 jo. 300.2.2-2430/2025). Sebelum sinkronisasi resmi, cocokkan lagi dengan lampiran pemutakhiran Kemendagri 2025 atau data Dukcapil/Back-Office terbaru.
- 12 desa pada jadwal gelombang 2026 berbeda dari daftar 12 desa yang sebelumnya terlihat pada dropdown website. Hanya 3 nama yang sama: Toho Ilir, Sengkubang, dan Antibar. Pastikan daftar baru ini memang menggantikan daftar lama sebagai 12 desa gelombang berjalan sebelum data website diubah.

Total dari screenshot: 12 desa, 5 gelombang, 72 TPS.
