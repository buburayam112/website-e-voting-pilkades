MASTER REFERENSI KODE 60 DESA KABUPATEN MEMPAWAH

Isi:
- kode-60-desa-mempawah.csv
- kode-60-desa-mempawah.json

Sumber daftar kode desa individual:
Lampiran Peraturan Bupati Mempawah Nomor 43 Tahun 2022 tentang Kode dan Data Wilayah Administrasi Pemerintahan Kabupaten Mempawah Tahun 2022 (status tercatat Berlaku pada JDIH BPK).

Format kode:
- Kolom kode_kemendagri berisi 10 digit tanpa titik, disimpan sebagai STRING.
- Kolom kode_tampilan berisi format visual bertitik sesuai lampiran Perbup.
- Hanya 60 DESA yang dimasukkan; 7 KELURAHAN tidak dimasukkan.

Catatan verifikasi:
Keputusan Mendagri Nomor 300.2.2-2138 Tahun 2025 dan perubahannya, Nomor 300.2.2-2430 Tahun 2025, merupakan pemutakhiran nasional yang lebih baru. Daftar ini dikompilasi dari lampiran Perbup Mempawah 43/2022 yang mencantumkan kode individual desa. Sebelum sinkronisasi API produksi, cocokkan lagi dengan data Dukcapil/Back-Office terbaru dari Diskominfo atau perangkat daerah berwenang.

Jangan menebak atau menyamakan kode internal Back-Office dengan kode wilayah Kemendagri.
